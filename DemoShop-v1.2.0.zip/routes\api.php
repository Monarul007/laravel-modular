<?php

use Illuminate\Support\Facades\Route;
use Modules\DemoShop\Http\Controllers\ShopController;

Route::prefix('api/v1/shop')->group(function () {
    Route::get('products', [ShopController::class, 'products']);
    Route::post('cart/add', [ShopController::class, 'addToCart']);
    Route::get('cart', [ShopController::class, 'getCart']);
});