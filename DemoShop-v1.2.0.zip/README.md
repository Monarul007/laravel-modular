# DemoShop Module

A demonstration e-commerce module for the Laravel Modular System.

## Features

- Product listing API
- Shopping cart functionality
- Basic checkout process
- RESTful API endpoints

## API Endpoints

### Get Products
```
GET /api/v1/shop/products
```

### Add to Cart
```
POST /api/v1/shop/cart/add
Body: {"product_id": 1, "quantity": 2}
```

### Get Cart
```
GET /api/v1/shop/cart
```

## Installation

This module can be installed via ZIP upload through the admin panel or by placing the module files in the `modules/DemoShop` directory.

## Version History

- v1.2.0 - Added cart functionality
- v1.1.0 - Enhanced product management
- v1.0.0 - Initial release