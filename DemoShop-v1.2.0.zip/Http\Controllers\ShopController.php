<?php

namespace Modules\DemoShop\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\ApiResponse;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ShopController extends Controller
{
    public function products(): JsonResponse
    {
        $products = [
            [
                'id' => 1,
                'name' => 'Demo Product 1',
                'price' => 29.99,
                'description' => 'This is a demo product for testing',
                'stock' => 10
            ],
            [
                'id' => 2,
                'name' => 'Demo Product 2', 
                'price' => 49.99,
                'description' => 'Another demo product',
                'stock' => 5
            ]
        ];

        return ApiResponse::success($products, 'Products retrieved successfully');
    }

    public function addToCart(Request $request): JsonResponse
    {
        $request->validate([
            'product_id' => 'required|integer',
            'quantity' => 'required|integer|min:1'
        ]);

        // In a real implementation, you would:
        // 1. Validate product exists and has stock
        // 2. Add to user's cart in database
        // 3. Update stock levels

        return ApiResponse::success([
            'product_id' => $request->product_id,
            'quantity' => $request->quantity,
            'message' => 'Product added to cart successfully'
        ], 'Item added to cart');
    }

    public function getCart(): JsonResponse
    {
        // Mock cart data
        $cart = [
            'items' => [
                [
                    'product_id' => 1,
                    'name' => 'Demo Product 1',
                    'price' => 29.99,
                    'quantity' => 2,
                    'total' => 59.98
                ]
            ],
            'total' => 59.98,
            'item_count' => 2
        ];

        return ApiResponse::success($cart, 'Cart retrieved successfully');
    }
}