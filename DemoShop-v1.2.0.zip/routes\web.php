<?php

use Illuminate\Support\Facades\Route;

Route::prefix('demoshop')->group(function () {
    // Add your web routes here
});