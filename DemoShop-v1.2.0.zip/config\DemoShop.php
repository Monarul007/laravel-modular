<?php

return [
    'name' => 'DemoShop',
    'enabled' => true,
    
    // Add your module configuration here
];